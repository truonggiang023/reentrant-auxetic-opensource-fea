import json,math
from pathlib import Path
import numpy as np,gmsh
from shapely.geometry import LineString
from shapely.ops import unary_union
from reentrant_fea.geometry import core_polygon,parameters
p=Path('results/calibration_completion/structured');p.mkdir(exist_ok=True)
c=json.load(open('configs/dong2019_brick_damage.json'));h,shift,pitch=parameters(c);t=c['wall'];raw=[]
def edges(pts):
 raw.extend(LineString([a,b]) for a,b in zip(pts,pts[1:]))
for j in range(c['cols']):
 x=j*pitch;pts=[(x,0)]
 for i in range(c['rows']):pts.extend([(x+shift,(i+.5)*h),(x,(i+1)*h)])
 pts.append((x+c['l1'],c['height']))
 for i in reversed(range(c['rows'])):pts.extend([(x+c['l1']-shift,(i+.5)*h),(x+c['l1'],i*h)])
 pts.append(pts[0]);edges(pts)
 for i in range(1,c['rows']):edges([(x,i*h),(x+c['l1'],i*h)])
 if j<c['cols']-1:
  for i in range(c['rows']):
   y=(i+.5)*h;edges([(x+c['l1']-shift,y),((j+1)*pitch+shift,y)])
network=unary_union(raw);core=core_polygon(c);strips=[]
for line in network.geoms:
 coords=list(line.coords)
 for a,b in zip(coords,coords[1:]):
  a,b=np.array(a),np.array(b);length=np.linalg.norm(b-a);u=(b-a)/length;trim=1.5*t
  if length<=2*trim:continue
  rect=LineString([a+trim*u,b-trim*u]).buffer(t/2,cap_style=2)
  if rect.difference(core).area>1e-9:raise ValueError('strip outside core')
  strips.append(rect)
union=unary_union(strips)
if abs(sum(s.area for s in strips)-union.area)>1e-8:raise ValueError('overlapping strips')
junction=core.difference(union)
patches=strips+list(junction.geoms if junction.geom_type=='MultiPolygon' else [junction])
print('patches',len(strips),len(patches)-len(strips),'area',sum(s.area for s in patches),core.area,flush=True)
gmsh.initialize()
try:
 gmsh.model.add('wallblocks');points={};curves={};structured=[]
 def point(xy):
  key=tuple(round(float(v),9) for v in xy)
  if key not in points:points[key]=gmsh.model.geo.addPoint(*key,0,.8)
  return points[key]
 def loop(coords):
  ids=[point(v) for v in list(coords)[:-1]];es=[];lengths=[]
  for a,b,aa,bb in zip(ids,ids[1:]+ids[:1],list(coords)[:-1],list(coords)[1:]):
   if a==b:continue
   k=tuple(sorted((a,b)))
   if k not in curves:curves[k]=(gmsh.model.geo.addLine(a,b),a,b)
   tag,aaid,bbid=curves[k];es.append(tag if a==aaid else -tag);lengths.append(float(np.linalg.norm(np.array(aa)-bb)))
  return gmsh.model.geo.addCurveLoop(es),es,lengths
 for i,poly in enumerate(patches):
  l,es,lengths=loop(poly.exterior.coords);holes=[loop(r.coords)[0] for r in poly.interiors];s=gmsh.model.geo.addPlaneSurface([l]+holes)
  if i<len(strips):
   if len(es)!=4:raise ValueError('nonrectangular strip')
   structured.append((s,es,lengths))
 gmsh.model.geo.synchronize()
 requests={}
 for s,es,lengths in structured:
  for e,L in zip(es,lengths):
   count=2 if abs(L-t)<1e-6 else max(2,int(math.ceil(L/.8))+1)
   if abs(e) in requests and requests[abs(e)]!=count:raise ValueError('edge count mismatch')
   requests[abs(e)]=count
  gmsh.model.mesh.setTransfiniteSurface(s)
  gmsh.model.mesh.setRecombine(2,s)
 for e,count in requests.items():gmsh.model.mesh.setTransfiniteCurve(e,count)
 for key,val in [('Mesh.MeshSizeMin',.15),('Mesh.MeshSizeMax',.8),('Mesh.Algorithm',8),('Mesh.RecombineAll',1),('Mesh.RecombinationAlgorithm',1)]:gmsh.option.setNumber(key,val)
 gmsh.model.mesh.generate(2);gmsh.option.setNumber('Mesh.SubdivisionAlgorithm',1);gmsh.model.mesh.refine()
 tags,xyz,_=gmsh.model.mesh.getNodes();coords={int(tag):np.array(xyz[3*i:3*i+2]) for i,tag in enumerate(tags)}
 types,_,groups=gmsh.model.mesh.getElements(2);quads=[]
 for typ,flat in zip(types,groups):
  if gmsh.model.mesh.getElementProperties(typ)[0]!='Quadrilateral 4':raise ValueError('not all quad')
  quads.extend(np.asarray(flat).reshape(-1,4))
 used=sorted({int(v) for q in quads for v in q});mapping={tag:i for i,tag in enumerate(used)};xy=np.array([coords[tag] for tag in used]);qq=[]
 for q in quads:
  ids=[mapping[int(tag)] for tag in q];v=xy[ids];area=.5*np.sum(v[:,0]*np.roll(v[:,1],-1)-v[:,1]*np.roll(v[:,0],-1))
  if area<0:ids=[ids[0],ids[3],ids[2],ids[1]]
  qq.append(ids)
 nn=len(xy);n=np.array([[x,y,z] for z in (0.,25.) for x,y in xy]);e=np.array([q+[v+nn for v in q] for q in qq]);top=np.flatnonzero(abs(n[:,1]-n[:,1].max())<1e-7);bottom=np.flatnonzero(abs(n[:,1]-n[:,1].min())<1e-7)
 v=n[e[:,:4],:2];aa=np.roll(v,-1,axis=1)-v;bb=np.roll(v,1,axis=1)-v;ang=np.degrees(np.arccos(np.clip(np.sum(aa*bb,axis=2)/np.linalg.norm(aa,axis=2)/np.linalg.norm(bb,axis=2),-1,1))).min(1)
 area=.5*np.sum(v[:,:,0]*np.roll(v[:,:,1],-1,axis=1)-v[:,:,1]*np.roll(v[:,:,0],-1,axis=1));print('elementarea',area.sum(),'target',core.area,flush=True)
 if not np.isclose(area.sum(),core.area,rtol=1e-8):raise ValueError('meshed area mismatch')
 m=json.load(open('results/calibration_completion/deep_mesh.json'));m['nodes']=[[i+1,*r] for i,r in enumerate(n.tolist())];m['elements']=[[i+1,*[int(v+1) for v in row]] for i,row in enumerate(e)];anchor=min((int(i) for i in bottom),key=lambda i:(abs(n[i,0]-(n[:,0].min()+n[:,0].max())/2),i))
 m['boundary']=dict(all_z_fixed=list(range(1,len(n)+1)),bottom_y_fixed=(bottom+1).tolist(),top_y_displaced=(top+1).tolist(),one_bottom_x_pin=anchor+1,prescribed_top_y_mm=-.01)
 m['structured_diagnostic']=dict(core_elements=len(e),core_nodes=len(n),area=area.sum(),angle_percentiles=np.percentile(ang,[0,1,5,25,50,75]).tolist(),fraction_below60=float((ang<60).mean()))
 (p/'mesh.json').write_text(json.dumps(m,separators=(',',':')));np.savez_compressed(p/'mesh.npz',nodes=n,elements=e,top=top,bottom=bottom);print(m['structured_diagnostic'],flush=True)
finally:gmsh.finalize()
